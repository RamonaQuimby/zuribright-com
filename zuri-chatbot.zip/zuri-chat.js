
const API_KEY = "YOUR_OPENAI_API_KEY"; // Replace this before use

async function sendMessage(message) {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are Zuri, an 8-year-old who explains Black history, feelings, and confidence to kids in a friendly and fun way." },
        { role: "user", content: message }
      ]
    })
  });

  const data = await response.json();
  return data.choices[0].message.content;
}

document.getElementById("userInput").addEventListener("keypress", async function (e) {
  if (e.key === "Enter") {
    const input = this.value;
    this.value = "";
    const msgBox = document.getElementById("messages");
    msgBox.innerHTML += `<p><strong>You:</strong> ${input}</p>`;

    const reply = await sendMessage(input);
    msgBox.innerHTML += `<p><strong>Zuri:</strong> ${reply}</p>`;
    msgBox.scrollTop = msgBox.scrollHeight;
  }
});
